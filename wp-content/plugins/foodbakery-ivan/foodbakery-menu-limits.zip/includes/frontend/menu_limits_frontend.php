<?php

// Direct access not allowed.
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('Menu_Limits_Frontend')) {

    /**
     * Class Menu_Limits_Frontend
     */
    class Menu_Limits_Frontend {

        /**
         * Menu_Limits_Frontend constructor.
         */
        public function __construct() {
            add_action('foodbakery_menu_item_cart_before_adding', array($this, 'foodbakery_menu_item_cart_before_adding_callback'), 11, 2);
            add_action('wp_ajax_foodbakery_empty_restaurant_cart', array($this, 'foodbakery_empty_restaurant_cart_callback'), 11);
            add_action('wp_ajax_nopriv_foodbakery_empty_restaurant_cart', array($this, 'foodbakery_empty_restaurant_cart_callback'), 11);

            //Quantity Check
            add_action('foodbakery_menu_item_cart_before_adding', array($this, 'cart_before_adding_quantity_check_callback'), 11, 2);
            add_action('foodbaekery_confirm_order_process_before', array($this, 'foodbaekery_confirm_order_process_before_callback'), 11);
            
            add_filter('foodbakery_restaurant_fields_frontend', array($this, 'foodbakery_restaurant_fields_frontend_callback'), 10, 2);
            
        }
        
        /*
         * Frontend Fields in Restaurant Settings
         */

        public function foodbakery_restaurant_fields_frontend_callback($html, $restaurant_id) {
            global $foodbakery_form_fields, $foodbakery_form_fields_frontend;

            $foodbakery_restaurant_minimum_cart_items = get_post_meta($restaurant_id, 'foodbakery_restaurant_minimum_cart_items', true);
            $foodbakery_restaurant_maximum_cart_items = get_post_meta($restaurant_id, 'foodbakery_restaurant_maximum_cart_items', true);
            
            $html .= '<div class="row">';
            
            $html .= '<div class="foodbakery-form-field col-lg-6 col-md-6 col-sm-12 col-xs-12"><div class="field-holder"><label>' . esc_html__('Minimum Cart Items', 'foodbakery-menu-limits') . '</label>';
            $html .= $foodbakery_form_fields->foodbakery_form_text_render(
                    array(
                        'cust_name' => 'foodbakery_restaurant_minimum_cart_items',
                        'cust_type' => 'number',
                        'std' => $foodbakery_restaurant_minimum_cart_items,
                        'desc' => '',
                        'classes' => 'foodbakery-dev-req-field form-control',
                        'extra_atr' => ' placeholder="' . esc_html__('Minimum Cart Items', 'foodbakery-menu-limits') . '"',
                        'return' => true,
                        'hint_text' => '',
                    )
            );
            $html .= '</div></div>';
            
            
            $html .= '<div class="foodbakery-form-field col-lg-6 col-md-6 col-sm-12 col-xs-12"><div class="field-holder"><label>' . esc_html__('Maximum Cart Items', 'foodbakery-menu-limits') . '</label>';
            $html .= $foodbakery_form_fields->foodbakery_form_text_render(
                    array(
                        'cust_name' => 'foodbakery_restaurant_maximum_cart_items',
                        'cust_type' => 'number',
                        'std' => $foodbakery_restaurant_maximum_cart_items,
                        'desc' => '',
                        'classes' => 'foodbakery-dev-req-field form-control',
                        'extra_atr' => ' placeholder="' . esc_html__('Maximum Cart Items', 'foodbakery-menu-limits') . '"',
                        'return' => true,
                        'hint_text' => '',
                    )
            );
            $html .= '</div></div>';


            $html .= '</div>';
            return $html;
        }

        /*
         * Adding Checks before adding menu Item in Cart
         */

        public function foodbakery_menu_item_cart_before_adding_callback($restaurant_id, $get_added_menus) {
            $random_id = rand(99, 9999);
            if (!empty($get_added_menus) && count($get_added_menus) > 1 && (!isset($get_added_menus[$restaurant_id]))) {

                $li_html = '<div class="modal fade menu-extras-modal extras-deal-modal add_extrass" id="show-empty-cart-' . $random_id . '" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                            <h2><a>' . esc_html__('Cart Items', 'foodbakery-menu-limits') . '</a></h2>
                                        </div>
                                        <div class="modal-body">
                                        <div class="menu-selection-container">
                                            ' . esc_html__('You can only add items from one Home Chef, at a time. Do you want to Empty cart and Start Again?', 'foodbakery-menu-limits') . '
                                            <br>
                                            <br>
                                            <div class="extras-btns-holder">
                                                <button data-menucat-id="0" data-restaurant_id="' . $restaurant_id . '" class="empty-restaurant-cart input-button-loader">' . esc_html__('Empty Cart', 'foodbakery-menu-limits') . '</button>
                                                <a href="javascript:void(0)" data-dismiss="modal" class="reset-menu-fields btn">' . esc_html__('No', 'foodbakery-menu-limits') . '</a>
                                            </div>
                                            </div>

                                        </div>
                                     </div>
                                </div>
                            </div>
                     <script type="text/javascript">
                        jQuery("#show-empty-cart-' . $random_id . '").modal("show");
                        jQuery("#show-empty-cart-' . $random_id . '").prependTo("body");
                     </script>';

                $json = array('msg' => esc_html__('You can only add items from one Home Chef, at a time. Do you want to Empty cart and Start Again?', 'foodbakery-menu-limits'), 'type' => 'errors', 'li_html' => $li_html);
                echo json_encode($json);
                die;
            }
        }

        /*
         * Empty Restaurant Cart
         */

        public function foodbakery_empty_restaurant_cart_callback() {
            global $current_user;

            $restaurant_id = isset($_POST['restaurant_id']) ? $_POST['restaurant_id'] : '';
            $get_added_menus = array();

            if (is_user_logged_in()) {
                $user_id = $current_user->ID;
                $publisher_id = foodbakery_company_id_form_user_id($user_id);
                set_transient('add_menu_items_' . $publisher_id, $get_added_menus, 60 * 60 * 24 * 30);
                setcookie('add_menu_items_temp', serialize($get_added_menus), time() + (10 * 365 * 24 * 60 * 60), '/');
            } else {
                setcookie('add_menu_items_temp', serialize($get_added_menus), time() + (10 * 365 * 24 * 60 * 60), '/');
            }
        }

        /*
         * Check Quantity of Cart before Adding another item
         */

        public function cart_before_adding_quantity_check_callback($restaurant_id, $get_added_menus) {
            if (!empty($get_added_menus) && (isset($get_added_menus[$restaurant_id]))) {
                
                $max_quantity = get_post_meta($restaurant_id, 'foodbakery_restaurant_maximum_cart_items', true);
                $max_quantity   = ( $max_quantity == '')? 0 : $max_quantity;
                $cart_count = count($get_added_menus[$restaurant_id]);
                if( $max_quantity > 0){
                    if( $cart_count == $max_quantity || $cart_count > $max_quantity ){
                        $json = array('msg' => esc_html__('You cannot add more than '. $max_quantity .' items into cart', 'foodbakery-menu-limits'), 'type' => 'error');
                        echo json_encode($json);
                        die;
                    }
                }
            }
        }
        
        /*
         * Quantity Check on Confirm Order Process
         */
        public function foodbaekery_confirm_order_process_before_callback($restaurant_id){
            global $current_user;

            $get_added_menus = array();

            if (is_user_logged_in()) {
                $user_id = $current_user->ID;
                $publisher_id = foodbakery_company_id_form_user_id($user_id);
                $get_added_menus = get_transient('add_menu_items_' . $publisher_id);
            }else {
                $get_added_menus = unserialize(stripslashes($_COOKIE['add_menu_items_temp']));
            }
            if (!empty($get_added_menus) && (isset($get_added_menus[$restaurant_id]))) {
                
                $min_quantity = get_post_meta($restaurant_id, 'foodbakery_restaurant_minimum_cart_items', true);
                $min_quantity   = ( $min_quantity == '')? 0 : $min_quantity;
                $max_quantity = get_post_meta($restaurant_id, 'foodbakery_restaurant_maximum_cart_items', true);
                $max_quantity   = ( $max_quantity == '')? 0 : $max_quantity;
                
                if( $max_quantity > 0){
                    $cart_count = count($get_added_menus[$restaurant_id]);
                    if( $cart_count > $max_quantity ){
                        $json = array('msg' => esc_html__('You cannot add more than '. $max_quantity .' items into cart', 'foodbakery-menu-limits'), 'type' => 'error');
                        echo json_encode($json);
                        die;
                    }
                }
                if( $min_quantity > 0){
                    if( $cart_count < $min_quantity ){
                        $json = array('msg' => esc_html__('You cannot add less than '. $min_quantity .' items into cart', 'foodbakery-menu-limits'), 'type' => 'error');
                        echo json_encode($json);
                        die;
                    }
                }
            }
            
        }

    }

    new Menu_Limits_Frontend();
}
?>
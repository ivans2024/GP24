<?php

// Direct access not allowed.
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('Menu_Limits_Backend')) {

    /**
     * Class Menu_Limits_Backend
     */
    class Menu_Limits_Backend {

        /**
         * Menu_Limits_Backend constructor.
         */
        public function __construct() {
            add_action('foodbakery_restaurant_admin_fields_after_menu', array($this, 'foodbakery_restaurant_admin_fields_after_menu_callback'), 10);
            
        }
        
        /*
         * Backend Fields in Restaurant Settings
         */

        public function foodbakery_restaurant_admin_fields_after_menu_callback($restaurant_id) {
            global $foodbakery_html_fields;
           
            
             $foodbakery_html_fields->foodbakery_text_field(
                    array(
                        'name' => esc_html__('Minimum Cart Items', 'foodbakery-menu-limits'),
                        'id' => 'restaurant_minimum_cart_items',
                        'hint_text' => '',
                        'echo' => true,
                        'field_params' => array(
                            'std' => '',
                            'id' => 'restaurant_minimum_cart_items',
                            'return' => true,
                        ),
                    )
            );
            
            $foodbakery_html_fields->foodbakery_text_field(
                    array(
                        'name' => esc_html__('Maximum Cart Items', 'foodbakery-menu-limits'),
                        'id' => 'restaurant_maximum_cart_items',
                        'hint_text' => '',
                        'echo' => true,
                        'field_params' => array(
                            'std' => '',
                            'id' => 'restaurant_maximum_cart_items',
                            'return' => true,
                        ),
                    )
            );
            
        }

    }

    new Menu_Limits_Backend();
}
?>
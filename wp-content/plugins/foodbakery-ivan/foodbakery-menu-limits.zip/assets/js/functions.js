jQuery(document).ajaxComplete(function () {
    jQuery(document).ready(function ($) {
        jQuery(document).on("click", ".empty-restaurant-cart", function () {
            jQuery(this).append('<div class="foodbakery-button-loader" style="display: block;"><div class="spinner"><div class="double-bounce1"></div><div class="double-bounce2"></div></div></div>');
            var restaurant_id = jQuery(this).data('restaurant_id');
             jQuery.ajax({
                type: "POST",
                url: foodbakery_menu_limits.ajax_url,
                data: 'action=foodbakery_empty_restaurant_cart&restaurant_id=' + restaurant_id,
                success: function (response) {
                    location.reload();
                }
            });
            
        });
    });
});